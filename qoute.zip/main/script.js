                    // Handle the scroll effect for article cards and navbar background
                    window.addEventListener('scroll', () => {
                        document.querySelectorAll('.article-card').forEach(card => {
                            let position = card.getBoundingClientRect().top;
                            let screenHeight = window.innerHeight;
                            if (position < screenHeight - 100) {
                                card.classList.add('show');
                            }
                        });

                        const navbar = document.querySelector('.navbar');
                        navbar.style.background = window.scrollY > 50 ? 'rgba(255,255,255,0.98)' : 'rgba(255,255,255,0.95)';
                    });

                    // Smooth scrolling for anchor links
                    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                        anchor.addEventListener('click', function(e) {
                            e.preventDefault();
                            document.querySelector(this.getAttribute('href')).scrollIntoView({
                                behavior: 'smooth'
                            });
                        });
                    });

                    // Theme toggle with saving in localStorage
                    document.querySelector('.theme-toggle').addEventListener('click', function() {
                        const body = document.body;
                        const icon = this.querySelector('i');

                        // Toggle between light and dark themes
                        if (body.classList.contains('light-theme')) {
                            body.classList.remove('light-theme');
                            body.classList.add('dark-theme');
                            icon.classList.remove('fa-moon');
                            icon.classList.add('fa-sun');
                            // Save to localStorage
                            localStorage.setItem('theme', 'dark');
                        } else {
                            body.classList.remove('dark-theme');
                            body.classList.add('light-theme');
                            icon.classList.remove('fa-sun');
                            icon.classList.add('fa-moon');
                            // Save to localStorage
                            localStorage.setItem('theme', 'light');
                        }
                    });

                    // Apply saved theme on page load
                    window.addEventListener('load', () => {
                        const savedTheme = localStorage.getItem('theme');
                        const body = document.body;
                        const icon = document.querySelector('.theme-toggle i');

                        if (savedTheme === 'dark') {
                            body.classList.add('dark-theme');
                            body.classList.remove('light-theme');
                            icon.classList.add('fa-sun');
                            icon.classList.remove('fa-moon');
                        } else {
                            body.classList.add('light-theme');
                            body.classList.remove('dark-theme');
                            icon.classList.add('fa-moon');
                            icon.classList.remove('fa-sun');
                        }
                    });


                    document.getElementById('shareBtn').addEventListener('click', async () => {
                        const shareData = {
                            title: document.title,
                            text: 'Check out this website!',
                            url: window.location.href
                        };

                        if (navigator.share) {
                            try {
                                await navigator.share(shareData);
                                console.log('Content shared successfully');
                            } catch (err) {
                                console.error('Error sharing:', err);
                            }
                        } else {
                            // Fallback: copy URL to clipboard
                            copyToClipboard(window.location.href);
                            alert('Link copied to clipboard!');
                        }
                    });

                    function copyToClipboard(text) {
                        const textarea = document.createElement('textarea');
                        textarea.value = text;
                        // Avoid scrolling to bottom
                        textarea.style.top = '0';
                        textarea.style.left = '0';
                        textarea.style.position = 'fixed';
                        document.body.appendChild(textarea);
                        textarea.focus();
                        textarea.select();
                        try {
                            document.execCommand('copy');
                        } catch (err) {
                            console.error('Unable to copy', err);
                        }
                        document.body.removeChild(textarea);
                    }

                    document.addEventListener("DOMContentLoaded", function() {
                        const eventContainer = document.getElementById("event-container");
                        const eventAudio = document.getElementById("event-audio");
                        const playButton = document.getElementById("playEventBtn");

                        function playEvent() {
                            eventContainer.style.display = "block"; // Show event section
                            eventAudio.play(); // Auto-play audio
                        }

                        if (playButton) {
                            playButton.addEventListener("click", playEvent);
                        }
                    });

                    document.addEventListener("DOMContentLoaded", function() {
                        const articleSection = document.getElementById("bluenity");
                        const toggleButton = document.getElementById("toggleArticleBtn");
                        const eventContainer = document.getElementById("event-container");
                        const eventAudio = document.getElementById("event-audio");

                        function toggleArticle() {
                            if (articleSection.style.display === "block") {
                                articleSection.style.display = "none";
                                toggleButton.innerHTML = '<i class="fas fa-info-circle"></i> Read Article';
                            } else {
                                articleSection.style.display = "block";
                                eventContainer.style.display = "none"; // Hide event content
                                toggleButton.innerHTML = '<i class="fas fa-times"></i> Close Article';
                            }
                        }

                        function playEvent() {
                            eventContainer.style.display = "block";
                            articleSection.style.display = "none"; // Hide article section
                            toggleButton.innerHTML = '<i class="fas fa-info-circle"></i> Read Article'; // Reset button text

                            if (eventAudio) {
                                eventAudio.play();
                            }
                        }

                        // Attach event listeners to buttons
                        if (toggleButton) {
                            toggleButton.addEventListener("click", toggleArticle);
                        }

                        const playButton = document.querySelector(".play-btn");
                        if (playButton) {
                            playButton.addEventListener("click", playEvent);
                        }
                    });



                    document.addEventListener("DOMContentLoaded", function() {
                        const articleSection = document.getElementById("Rebluiton");
                        const toggleButton = document.getElementById("toggleArticleBtnRebluiton");
                        const eventContainer = document.getElementById("event-container-rebluiton");
                        const eventAudio = document.getElementById("event-audio-rebluiton");
                        const playButton = document.getElementById("playEventBtnRebluiton");

                        function toggleArticle() {
                            if (articleSection.style.display === "block") {
                                articleSection.style.display = "none";
                                toggleButton.innerHTML = '<i class="fas fa-info-circle"></i> Read Article';
                            } else {
                                articleSection.style.display = "block";
                                eventContainer.style.display = "none"; // Hide event content
                                toggleButton.innerHTML = '<i class="fas fa-times"></i> Close Article';
                            }
                        }

                        function playEvent() {
                            eventContainer.style.display = "block";
                            articleSection.style.display = "none"; // Hide article section
                            toggleButton.innerHTML = '<i class="fas fa-info-circle"></i> Read Article'; // Reset button text

                            if (eventAudio) {
                                eventAudio.play();
                            }
                        }

                        // Attach event listeners to buttons
                        if (toggleButton) {
                            toggleButton.addEventListener("click", toggleArticle);
                        }

                        if (playButton) {
                            playButton.addEventListener("click", playEvent);
                        }
                    });





    // Your Firebase configuration
    var firebaseConfig = {
      apiKey: "AIzaSyDiKlAN4ORwkfAM4PPN-gtQ_SlOWDx6ROE",
      authDomain: "ratings-39797.firebaseapp.com",
      databaseURL: "https://ratings-39797-default-rtdb.firebaseio.com",
      projectId: "ratings-39797",
      storageBucket: "ratings-39797.appspot.com",
      messagingSenderId: "265725111546",
      appId: "1:265725111546:web:152cad37914deeb4beed43"
    };

    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
    var database = firebase.database();

    document.addEventListener("DOMContentLoaded", function () {
      var stars = document.querySelectorAll(".star");
      var submitRatingBtn = document.getElementById("submitRating");
      var averageRatingElement = document.getElementById("averageRating");
      var recommendPercentageElement = document.getElementById("recommendPercentage");
      var totalRatingsElement = document.getElementById("totalRatings");

      var selectedRating = 0;

      // Handle star click
      stars.forEach(function(star) {
        star.addEventListener("click", function () {
          selectedRating = parseInt(this.getAttribute("data-value"));
          updateStars(selectedRating);
        });
      });

      // Update star visuals
      function updateStars(rating) {
        stars.forEach(function(star) {
          var starValue = parseInt(star.getAttribute("data-value"));
          star.innerHTML = starValue <= rating ? "&#9733;" : "&#9734;";
          if (starValue <= rating) {
            star.classList.add("selected");
          } else {
            star.classList.remove("selected");
          }
        });
      }

      // Submit rating
      submitRatingBtn.addEventListener("click", function () {
        if (selectedRating > 0) {
          var newRatingRef = database.ref("ratings").push();
          newRatingRef.set({ rating: selectedRating })
          .then(function () {
            alert("Thank you for rating!");
            selectedRating = 0;
            updateStars(0);
            fetchRatings();
          })
          .catch(function (error) {
            console.error("Error submitting rating:", error);
          });
        } else {
          alert("Please select a rating.");
        }
      });

      // Fetch and calculate ratings
      function fetchRatings() {
        database.ref("ratings").once("value").then(function(snapshot) {
          var totalRatings = 0;
          var ratingSum = 0;
          var fiveStarCount = 0;

          snapshot.forEach(function(childSnapshot) {
            var rating = childSnapshot.val().rating;
            ratingSum += rating;
            totalRatings++;
            if (rating === 5) {
              fiveStarCount++;
            }
          });

          var averageRating = totalRatings > 0 ? (ratingSum / totalRatings).toFixed(1) : "0.0";
          var recommendPercentage = totalRatings > 0 ? ((fiveStarCount / totalRatings) * 100).toFixed(1) + "%" : "0%";

          averageRatingElement.textContent = averageRating;
          recommendPercentageElement.textContent = recommendPercentage;
          totalRatingsElement.textContent = totalRatings;
        })
        .catch(function(error) {
          console.error("Error fetching ratings:", error);
        });
      }

      // Initial ratings fetch on page load
      fetchRatings();
    });